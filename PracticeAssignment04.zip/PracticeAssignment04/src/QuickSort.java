
/**
 * *
 * QuickSort: A Quick Sort Algorithm class that implements the SortingAlgorithm interface.
 *This class may have references to class, websites, and other online sources
 */
public class QuickSort implements SortingAlgorithm {
    /**
     * sort method implemented from interface which runs the quick sort method
     * @param a
     */
    @Override
    public void sort(int[] a)
    {
        this.qSort(a, 0, a.length - 1);
    }

    /**
     * quick sort algorithm method which accepts the min and max values as well as the source array and runs quick sort on it
     * @param arr
     * @param start
     * @param end
     */
    void qSort(int arr[], int start, int end)
    {
        if (start < end)
        {

            int pi = partition(arr, start, end);

            qSort(arr, start, pi-1);
            qSort(arr, pi+1, end);
        }
    }

    /**
     * partition method which determines the partition in the array and adjusts the pivots when a certain limit has been reached
     * @param arr
     * @param start
     * @param end
     * @return
     */
    public int partition(int arr[], int start, int end)
    {
        int pivot = arr[end];
        int i = (start-1);
        for (int j=start; j<end; j++)
        {

            if (arr[j] < pivot)
            {
                i++;


                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
            }
        }


        int temp = arr[i+1];
        arr[i+1] = arr[end];
        arr[end] = temp;

        return i+1;
    }
}
