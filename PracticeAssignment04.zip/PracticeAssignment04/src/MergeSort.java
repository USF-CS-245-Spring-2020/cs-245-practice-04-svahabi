/**
 * *
 * MergeSort: An Insertion Sort Algorithm class that implements the SortingAlgorithm interface.
 *This class may have references to class, websites, and other online sources
 */
public class MergeSort implements SortingAlgorithm {
    /**
     * sort method implemented from interface which runs the mergesort algorithm method
     * @param arr
     */
    @Override
    public void sort(int arr[]) {
        mSort(arr, arr.length);
    }

    /**
     * merge sort algorithm method which runs a merge sort on array a
     * @param a
     * @param n
     */
    public static void mSort(int[] a, int n) {
        if (n < 2) {
            return;
        }
        int mid = n / 2;
        int[] left = new int[mid];
        int[] right = new int[n - mid];

        for (int i = 0; i < mid; i++) {
            left[i] = a[i];
        }
        for (int i = mid; i < n; i++) {
            right[i - mid] = a[i];
        }
        mSort(left, mid);
        mSort(right, n - mid);

        merge(a, left, right, mid, n - mid);
    }

    /**
     * merge method used to merge the split up arrays back into the sorted full array
     * @param a
     * @param leftArr
     * @param rightArr
     * @param left
     * @param right
     */
    public static void merge(int[] a, int[] leftArr, int[] rightArr, int left, int right)
    {
        int i = 0, j = 0, k = 0;
        while (i < left && j < right) {
            if (leftArr[i] <= rightArr[j]) {
                a[k++] = leftArr[i++];
            }
            else{
                a[k++] = rightArr[j++];
            }
        }
        while (i < left){
            a[k++] = leftArr[i++];
        }
        while (j < right) {
            a[k++] = rightArr[j++];
        }
    }
}
