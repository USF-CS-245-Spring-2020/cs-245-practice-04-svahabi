/**
 * *
 * InsertionSort: An Insertion Sort Algorithm class that implements the Practice03Sort interface.
 * This class may have references to class, websites, and other online sources
 */
public class InsertionSort implements SortingAlgorithm{
    /**
     * Insertion sort method which sorts the values in array "a".
     * @param a
     */
    @Override
    public void sort(int[] a) {
        for (int i = 0; i < a.length; i++){
            int temp = a[i];
            int j = i-1;
            while(j>=0 && temp < a[j]){
                a[j+1] = a[j];
                --j;
            }
            a[j+1] = temp;
        }
    }

}

